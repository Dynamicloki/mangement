<?php
	function checkInput($inputString)
	{
		return htmlspecialchars(trim($inputString));
	}
?>