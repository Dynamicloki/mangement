<?php
$testId=$_REQUEST["testId"]:
?>
<div class="row">

<div class="mb-3 col-md-6">
  <label for="exampleFormControlInput1" class="form-label">Total Marks</label>
  <input type="number" id ="test1" class="form-control" placeholder="Total Marks" name="totalMarks">
</div>
<div class="mb-3">
	<button type="submit" class="btn btn-primary">Add Tests</button>
</div>
</div>