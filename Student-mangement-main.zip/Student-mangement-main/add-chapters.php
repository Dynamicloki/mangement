<?php
 $chapterid=$_REQUEST["chapterid"];
?>
<form>
	<div class="mb-3">
		<label for="exampleInputPassword1" class="form-label">Password</label>
		<input type="text" class="form-control" name="test" id="test1" id="exampleInputPassword1">
	</div>
</form>