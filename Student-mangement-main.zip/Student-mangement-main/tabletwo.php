<?php 

for ($x = 1; $x <= 10; $x++) {
    echo "2 * $x = ";  
	echo $x * 2 ;
	echo " <br> " ;
		
} 
?>