<?php
include "dbms.php"
SELECT * FROM  tblclass;
?>