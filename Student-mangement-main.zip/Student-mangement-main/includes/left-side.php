<div class=" container-fluid">
	<div class="row">
		<div class="col-md-2 col-sm-2 side-bar">
				<li class="menu">
					<p>
						<a class="sidenav-link menu1" data-bs-toggle="collapse" href="#manageStudent" role="button" aria-expanded="false" aria-controls="collapseExample">Student Management</a>
					</p>
					<div class="collapse" id="manageStudent">
						<ul>
							<li class="menu"><a class="sidenav-link menu1" href="menu1.php">Add student</a></li>
							<li class="menu"><a class="sidenav-link menu1" href="table.php">All student</a></li>
						</ul>
					</div>
				</li>
				<li class="menu">
					<p>
						<a class="sidenav-link menu1" data-bs-toggle="collapse" href="#manageClass" role="button" aria-expanded="false" aria-controls="collapseExample">class Management</a>
					</p>
					<div class="collapse" id="manageClass">
						<ul>
							<li class="menu"><a class="sidenav-link menu1" href="add-class.php">Add class</a></li>
							<li class="menu"><a class="sidenav-link menu1" href="class-table.php">All class</a></li>
						</ul>
					</div>
				</li>
				<li class="menu">
					<p>
						<a class="sidenav-link menu1" data-bs-toggle="collapse" href="#managesubject" role="button" aria-expanded="false" aria-controls="collapseExample">Subject Management</a>
					</p>
					<div class="collapse" id="managesubject">
						<ul>
							<li class="menu"><a class="sidenav-link menu1" href="Add-subject.php">Add subject</a></li>
							<li class="menu"><a class="sidenav-link menu1" href="subjects-table.php">All subject</a></li>
						</ul>
					</div>
				</li>
				<li class="menu">
					<p>
						<a class="sidenav-link menu1" data-bs-toggle="collapse" href="#managechapter" role="button" aria-expanded="false" aria-controls="collapseExample">chapter Management</a>
					</p>
					<div class="collapse" id="managechapter">
						<ul>
							<li class="menu"><a class="sidenav-link menu1" href="add-chapter.php">Add chapter</a></li>
							<li class="menu"><a class="sidenav-link menu1" href="chapter-table.php">All chapter</a></li>
						</ul>
					</div>
				</li>
				<li class="menu">
					<p>
						<a class="sidenav-link menu1" data-bs-toggle="collapse" href="#managetest" role="button" aria-expanded="false" aria-controls="collapseExample">Test Management</a>
					</p>
					<div class="collapse" id="managetest">
						<ul>
							<li class="menu"><a class="sidenav-link menu1" href="add-test-mangement.php">Add test</a></li>
							<li class="menu"><a class="sidenav-link menu1" href="table.php">All test</a></li>
						</ul>
					</div>
				</li>
		</div>		
    <div class="col-md-10 col-sm-10" style="text-align:left">