
<div class=" text-center">
  <div class="row">
    <div class="col-md-2 col-sm-2  right-side">
	<ul >
	 
                    <li class="menu">
                        <a href="line1.php">My Link Two</a>
                    </li>

                    <li class="menu">
                        <a href="#">My Link Three </a>
                    </li>
                    <li class="menu">
                        <a href="#">My Link Four</a>
                    </li>
                     <li class="menu">
                        <a href="#">My Link Five </a>
                    </li>
					
	</ul>				
					
	</div>
    <div class="col-md-10 col-sm-10">blnk page555</div>
	
	</div>
</div>