<?php
include"project\New folder/admin.php";
?>