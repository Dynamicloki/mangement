<?php
include("home.php");
?> 
<?php
include("left-side.php");
?> 

<div class="col-md-6 col-sm-6 middle-part ">
					<span class="para">
					At FreeKaGyan.in, we have a collection of over 7000 Questions, with answers and detailed explanations. It is an Online Application, which not just helps you in preparation, but also in review of questions using "Select for Review" option, providing "Rough Space" feature for carrying out calculations, with inbuilt discussion board for each question, etc. Questions like this are asked in most State and Central Government Entrance Examinations. Even in most of the College admissions and private jobs, stress is given on Aptitude, General Knowledge, Reasoning and Data Interpretation. In whichever stage of your career you are at present, solving the questions provided at FreeKaGyan will not only hone your skills, but will also keep your brain active and smart. Go ahead, choose your favorite section, and start learning now.<br>
					Happy Learning!
					</span>
					<div class="row tera">
						<div class="card box1" style="width: 12rem;">
							<h5 class="card-title box-head">General Aptitude</h5>
							<div class="card-body">
								<div class="one">
									<img src="image/qa.png">
								</div>
								<div class="two">
									<li class="list">
										<img src="image/zarrow.gif">
											Aptitude 
										</li>
										<li class="list">
										<img src="image/zarrow.gif">
											Reasoning 
										</li>
										<li class="list">
											<img src="image/zarrow.gif" >
											Verbal Ability 
										</li>
										<li class="list">
											<img src="image/zarrow.gif">
												G.K 
									</li>
								</div>
							</div>
						</div>
						<div class="card " style="width: 12rem;">
						 <h5 class="card-title box-head">General Aptitude</h5>
							<div class="card-body">
								<div class="one">
									<img src="image/qa.png">
								</div>
								<div class="two">
									<li class="list">
										<img src="image/zarrow.gif">
											Aptitude 
										</li>
										<li class="list">
										<img src="image/zarrow.gif">
											Reasoning 
										</li>
										<li class="list">
											<img src="image/zarrow.gif">
											Verbal Ability 
										</li>
										<li class="list">
											<img src="image/zarrow.gif">
												G.K 
										</li>
								</div>
							</div>
						</div>
					</div>
						
						<div class="row tera">
							<div class="card box1" style="width: 12rem;">
							 <h5 class="card-title box-head">General Aptitude</h5>
								<div class="card-body">
									<div class="one">
										<img src="image/qa.png">
									</div>
									<div class="two">
										<li class="list">
											<img src="image/zarrow.gif" align="absmiddle">
												Aptitude 
											</li>
											<li class="list">
											<img src="image/zarrow.gif" align="absmiddle">
												Reasoning 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
												Verbal Ability 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
													G.K 
										</li>
									</div>
								</div>
							</div>
							<div class="card" style="width: 12rem;">
							 <h5 class="card-title box-head">General Aptitude</h5>
								<div class="card-body">
									<div class="one">
										<img src="image/qa.png">
									</div>
									<div class="two">
										<li class="list">
											<img src="image/zarrow.gif" align="absmiddle">
												Aptitude 
											</li>
											<li class="list">
											<img src="image/zarrow.gif" align="absmiddle">
												Reasoning 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
												Verbal Ability 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
													G.K 
										</li>
									</div>
								</div>
							</div>
						</div>
						<div class="row tera">
							<div class="card box1" style="width: 12rem;">
							 <h5 class="card-title box-head">General Aptitude</h5>
								<div class="card-body">
									<div class="one">
										<img src="image/qa.png">
									</div>
									<div class="two">
										<li class="list">
											<img src="image/zarrow.gif">
												Aptitude 
											</li>
											<li class="list">
											<img src="image/zarrow.gif">
												Reasoning 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
												Verbal Ability 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
													G.K 
										</li>
									</div>
								</div>
							</div>
							<div class="card" style="width: 12rem;">
							 <h5 class="card-title box-head">General Aptitude</h5>
								<div class="card-body">
									<div class="one">
										<img src="image/qa.png">
									</div>
									<div class="two">
										<li class="list">
											<img src="image/zarrow.gif" align="absmiddle">
												Aptitude 
											</li>
											<li class="list">
											<img src="image/zarrow.gif" align="absmiddle">
												Reasoning 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
												Verbal Ability 
											</li>
											<li class="list">
												<img src="image/zarrow.gif" align="absmiddle">
													G.K 
										</li>
									</div>
								</div>
							</div>
						</div>

