<div class="row">
				<div class="footer">
					Home | contact us | terms of use | privcy polices<br>
					<span class="f2"> Copyright © freekagyan.in All right Resevered <span>
				</div>
			
			</div>